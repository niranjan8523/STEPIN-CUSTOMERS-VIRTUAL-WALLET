# Customer's Virtual Wallet 

The main aim of this Project Customer Virtual Wallet is an application which is designed to generate the bills to the customer which can be used in any departmental store, shops, cafes etc. You can use this application to keep the records such as name, address, mobile number, paid amount, due amount, payment data etc. of your regular customer. As well as we can add new customers in the record.
![image1](https://user-images.githubusercontent.com/49841421/124639696-17cc3e80-deaa-11eb-80c3-316a04bddb62.jpeg)


|Code Quality|Contribution-Check|CppCheck-Action|C-Build|Codacy-Badge
|:--:|:--:|:--:|:--:|:--:|
[![Code Quality Score](https://www.code-inspector.com/project/24711/status/svg)](https://frontend.code-inspector.com/public/project/24711/Mini-project/dashboard)|[![Contribution check](https://github.com/vamsi1999/Mini-project/actions/workflows/gitinspector.yml/badge.svg)](https://github.com/vamsi1999/Mini-project/actions/workflows/gitinspector.yml)|[![cppcheck-action](https://github.com/vamsi1999/Mini-project/actions/workflows/cppcheck.yml/badge.svg)](https://github.com/vamsi1999/Mini-project/actions/workflows/cppcheck.yml)|[![C Build Status](https://github.com/vamsi1999/Mini-project/actions/workflows/cbuild.yml/badge.svg)](https://github.com/vamsi1999/Mini-project/actions/workflows/cbuild.yml)|[![Codacy Badge](https://app.codacy.com/project/badge/Grade/b9bcf28814874603b80ea870fea0a131)](https://www.codacy.com/gh/vamsi1999/Mini-project/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=vamsi1999/Mini-project&amp;utm_campaign=Badge_Grade)|
 
