# Creating account for a New Customer
![](output1.png)

# Printing the information of a existing customer
![](output2.png)

# Paying the Bills
![](output3.png)

# Printing the information of all customers
![](output4.png)

# Adding balance to the customer's E-Wallet
![](output5.png)