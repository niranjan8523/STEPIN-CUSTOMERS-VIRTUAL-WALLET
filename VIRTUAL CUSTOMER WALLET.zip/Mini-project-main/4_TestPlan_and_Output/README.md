#  Test Plan

|Test_ID|Description|Expected_input|Expected_output|
|-------|-----------|--------------|---------------|
|H_01|To check whether the name variable is given in strings or not|strings without spaces|Name variable should be assigned with the given string|
|H_02|check Whether the mobile number given contains only 10 digits|10 digit integer|The 10 digit number should be assigned to mobile Information placeholder|
|H_03|Checking whether the amount which customer wants to pay is less than or equal to his wallet balance|1.Floating point value 2. integer|Debit the used amount from Customer's wallet and update the new balance in real-time|
